package com.example.spring.integration.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.example.spring.integration.dto.json.response.Offer;
import com.example.spring.integration.gateway.ResponseQueueGateway;

@Component
public class JmsMessageReceiver {

	@Value("${offer.response.queue}")
	private String offerResponseQueue;

	@Autowired
	private JmsTemplate jmsTemplate;

	@Autowired
	private ResponseQueueGateway responseQueueGateway;

	public Offer receiveMessage() {
		Message message = jmsTemplate.receive(offerResponseQueue);

		TextMessage textMessage = (TextMessage) message;
		try {
			String text = textMessage.getText();
			System.out.println("received xml : " + text);
			
			Offer  offer = responseQueueGateway.xmlToJsonGateway(text);
			
			return offer;
		} catch (JMSException e) {
			e.printStackTrace();
			return null;
		}
	}
}