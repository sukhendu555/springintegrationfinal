package com.example.spring.integration.flow;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.stereotype.Component;

import com.example.spring.integration.dto.json.request.Offers;

@Component
public class OfferService {

	private static Log logger = LogFactory.getLog(OfferService.class);

	private long emsFvtDelay = 5000;

	private long emsOfferDelay = 1000;

	public void setHotDrinkDelay(long hotDrinkDelay) {
		this.emsFvtDelay = hotDrinkDelay;
	}

	public void setColdDrinkDelay(long coldDrinkDelay) {
		this.emsOfferDelay = coldDrinkDelay;
	}

	@ServiceActivator(inputChannel = "emsFvt", outputChannel = "objectToXmlObjChannel")
	public Offers prepareEmsFvt(Offers offers) {
		try {
			Thread.sleep(this.emsFvtDelay);
			logger.info(Thread.currentThread().getName() + " prepared emsFvt Offer");

			return offers;
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			return null;
		}
	}

	@ServiceActivator(inputChannel = "emsOffer", outputChannel = "objectToXmlObjChannel")
	public Offers prepareEmsOffer(Offers offers) {
		try {
			Thread.sleep(this.emsOfferDelay);
			logger.info(Thread.currentThread().getName() + " prepared emsOffer Offer");

			return offers;
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			return null;
		}
	}

}
