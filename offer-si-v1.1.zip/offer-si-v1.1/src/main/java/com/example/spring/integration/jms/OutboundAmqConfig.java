package com.example.spring.integration.jms;

import javax.jms.ConnectionFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.jms.JmsOutboundGateway;
import org.springframework.messaging.MessageChannel;

@Configuration
public class OutboundAmqConfig {

	@Value("${offer.request.queue}")
	private String offerRequestQueue;

	@Bean
	public MessageChannel outboundJmsChannel() {
		return new DirectChannel();
	}

	@Bean
	@ServiceActivator(inputChannel = "outboundJmsChannel")
	public JmsOutboundGateway jmsOutboundGateway(ConnectionFactory connectionFactory) {
		JmsOutboundGateway gateway = new JmsOutboundGateway();
		gateway.setConnectionFactory(connectionFactory);
		gateway.setRequestDestinationName(offerRequestQueue);

		return gateway;
	}
}