package com.example.spring.integration.gateway;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;

import com.example.spring.integration.dto.json.response.Offer;

@MessagingGateway
public interface ResponseQueueGateway {

	@Gateway(requestChannel = "xmlToJsonRequestChannel", replyChannel = "xmlToJsonResponseChannel")
	public Offer xmlToJsonGateway(String xml);
}
