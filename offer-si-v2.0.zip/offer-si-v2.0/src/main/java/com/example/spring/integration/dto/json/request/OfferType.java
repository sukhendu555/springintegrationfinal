package com.example.spring.integration.dto.json.request;

import java.io.Serializable;

/**
 * @author Kundan
 */
public enum OfferType implements Serializable{

	EMS,
	FVT,
	COPS,
	Graph

}
