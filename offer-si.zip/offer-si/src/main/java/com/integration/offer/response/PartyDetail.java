
package com.integration.offer.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "accountNumber",
    "balanceTransferIndicator",
    "balanceTransferCreditRiskIndicator"
})
@XmlRootElement
public class PartyDetail {

    @JsonProperty("accountNumber")
    @XmlElement
    private String accountNumber;
    @JsonProperty("balanceTransferIndicator")
    @XmlElement
    private String balanceTransferIndicator;
    @JsonProperty("balanceTransferCreditRiskIndicator")
    @XmlElement
    private String balanceTransferCreditRiskIndicator;
   
    @JsonProperty("accountNumber")
    public String getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty("accountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    @JsonProperty("balanceTransferIndicator")
    public String getBalanceTransferIndicator() {
        return balanceTransferIndicator;
    }

    @JsonProperty("balanceTransferIndicator")
    public void setBalanceTransferIndicator(String balanceTransferIndicator) {
        this.balanceTransferIndicator = balanceTransferIndicator;
    }

    @JsonProperty("balanceTransferCreditRiskIndicator")
    public String getBalanceTransferCreditRiskIndicator() {
        return balanceTransferCreditRiskIndicator;
    }

    @JsonProperty("balanceTransferCreditRiskIndicator")
    public void setBalanceTransferCreditRiskIndicator(String balanceTransferCreditRiskIndicator) {
        this.balanceTransferCreditRiskIndicator = balanceTransferCreditRiskIndicator;
    }

}
