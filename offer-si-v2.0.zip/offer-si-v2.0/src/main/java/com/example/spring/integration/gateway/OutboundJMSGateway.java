package com.example.spring.integration.gateway;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;

@MessagingGateway
public interface OutboundJMSGateway {

	@Gateway(requestChannel="outboundJmsChannel")
	public void sendToOutboundQueue(String message);
}
