package com.example.spring.integration.gateway;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;

import com.example.spring.integration.dto.json.request.Offers;


@MessagingGateway
public interface OfferGateway {

	@Gateway(requestChannel="offers")
	void sendOffers(Offers offers);

}
