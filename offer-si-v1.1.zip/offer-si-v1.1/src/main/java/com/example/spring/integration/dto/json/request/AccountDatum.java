
package com.example.spring.integration.dto.json.request;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "accountNumber",
    "accountIndex",
    "accountType",
    "thankyouPoint",
    "authorizedUserIndicator",
    "selectedAccount",
    "cashbackBalance",
    "currentBalance",
    "cops",
    "alerts",
    "cardsData",
    "cltId",
    "dltId",
    "bcEligibilityIndicator",
    "travelEligibilityIndicator",
    "mobileEligibilityIndicator",
    "transactionData"
})
@XmlRootElement
public class AccountDatum {

    @JsonProperty("accountNumber")
    @XmlElement
    private String accountNumber;
    @JsonProperty("accountIndex")
    @XmlElement
    private String accountIndex;
    @JsonProperty("accountType")
    @XmlElement
    private String accountType;
    @JsonProperty("thankyouPoint")
    @XmlElement
    private String thankyouPoint;
    @JsonProperty("authorizedUserIndicator")
    @XmlElement
    private String authorizedUserIndicator;
    @JsonProperty("selectedAccount")
    @XmlElement
    private String selectedAccount;
    @JsonProperty("cashbackBalance")
    @XmlElement
    private Integer cashbackBalance;
    @JsonProperty("currentBalance")
    @XmlElement
    private Integer currentBalance;
    @JsonProperty("cops")
    @XmlElement
    private String cops;
    @JsonProperty("alerts")
    @XmlElement
    private String alerts;
    @JsonProperty("cardsData")
    @XmlElement
    private CardsData cardsData;
    @JsonProperty("cltId")
    @XmlElement
    private String cltId;
    @JsonProperty("dltId")
    @XmlElement
    private String dltId;
    @JsonProperty("bcEligibilityIndicator")
    @XmlElement
    private String bcEligibilityIndicator;
    @JsonProperty("travelEligibilityIndicator")
    @XmlElement
    private String travelEligibilityIndicator;
    @JsonProperty("mobileEligibilityIndicator")
    @XmlElement
    private String mobileEligibilityIndicator;
    @JsonProperty("transactionData")
    @XmlElement
    private List<Object> transactionData = new ArrayList<Object>();
  
    @JsonProperty("accountNumber")
    public String getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty("accountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    @JsonProperty("accountIndex")
    public String getAccountIndex() {
        return accountIndex;
    }

    @JsonProperty("accountIndex")
    public void setAccountIndex(String accountIndex) {
        this.accountIndex = accountIndex;
    }

    @JsonProperty("accountType")
    public String getAccountType() {
        return accountType;
    }

    @JsonProperty("accountType")
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    @JsonProperty("thankyouPoint")
    public String getThankyouPoint() {
        return thankyouPoint;
    }

    @JsonProperty("thankyouPoint")
    public void setThankyouPoint(String thankyouPoint) {
        this.thankyouPoint = thankyouPoint;
    }

    @JsonProperty("authorizedUserIndicator")
    public String getAuthorizedUserIndicator() {
        return authorizedUserIndicator;
    }

    @JsonProperty("authorizedUserIndicator")
    public void setAuthorizedUserIndicator(String authorizedUserIndicator) {
        this.authorizedUserIndicator = authorizedUserIndicator;
    }

    @JsonProperty("selectedAccount")
    public String getSelectedAccount() {
        return selectedAccount;
    }

    @JsonProperty("selectedAccount")
    public void setSelectedAccount(String selectedAccount) {
        this.selectedAccount = selectedAccount;
    }

    @JsonProperty("cashbackBalance")
    public Integer getCashbackBalance() {
        return cashbackBalance;
    }

    @JsonProperty("cashbackBalance")
    public void setCashbackBalance(Integer cashbackBalance) {
        this.cashbackBalance = cashbackBalance;
    }

    @JsonProperty("currentBalance")
    public Integer getCurrentBalance() {
        return currentBalance;
    }

    @JsonProperty("currentBalance")
    public void setCurrentBalance(Integer currentBalance) {
        this.currentBalance = currentBalance;
    }

    @JsonProperty("cops")
    public String getCops() {
        return cops;
    }

    @JsonProperty("cops")
    public void setCops(String cops) {
        this.cops = cops;
    }

    @JsonProperty("alerts")
    public String getAlerts() {
        return alerts;
    }

    @JsonProperty("alerts")
    public void setAlerts(String alerts) {
        this.alerts = alerts;
    }

    @JsonProperty("cardsData")
    public CardsData getCardsData() {
        return cardsData;
    }

    @JsonProperty("cardsData")
    public void setCardsData(CardsData cardsData) {
        this.cardsData = cardsData;
    }

    @JsonProperty("cltId")
    public String getCltId() {
        return cltId;
    }

    @JsonProperty("cltId")
    public void setCltId(String cltId) {
        this.cltId = cltId;
    }

    @JsonProperty("dltId")
    public String getDltId() {
        return dltId;
    }

    @JsonProperty("dltId")
    public void setDltId(String dltId) {
        this.dltId = dltId;
    }

    @JsonProperty("bcEligibilityIndicator")
    public String getBcEligibilityIndicator() {
        return bcEligibilityIndicator;
    }

    @JsonProperty("bcEligibilityIndicator")
    public void setBcEligibilityIndicator(String bcEligibilityIndicator) {
        this.bcEligibilityIndicator = bcEligibilityIndicator;
    }

    @JsonProperty("travelEligibilityIndicator")
    public String getTravelEligibilityIndicator() {
        return travelEligibilityIndicator;
    }

    @JsonProperty("travelEligibilityIndicator")
    public void setTravelEligibilityIndicator(String travelEligibilityIndicator) {
        this.travelEligibilityIndicator = travelEligibilityIndicator;
    }

    @JsonProperty("mobileEligibilityIndicator")
    public String getMobileEligibilityIndicator() {
        return mobileEligibilityIndicator;
    }

    @JsonProperty("mobileEligibilityIndicator")
    public void setMobileEligibilityIndicator(String mobileEligibilityIndicator) {
        this.mobileEligibilityIndicator = mobileEligibilityIndicator;
    }

    @JsonProperty("transactionData")
    public List<Object> getTransactionData() {
        return transactionData;
    }

    @JsonProperty("transactionData")
    public void setTransactionData(List<Object> transactionData) {
        this.transactionData = transactionData;
    }

}
