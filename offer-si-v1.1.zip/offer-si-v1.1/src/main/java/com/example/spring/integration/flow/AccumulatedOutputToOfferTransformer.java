package com.example.spring.integration.flow;

import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.example.spring.integration.dto.json.response.Offer;
import com.example.spring.integration.dto.json.response.Party;

@Component
public class AccumulatedOutputToOfferTransformer extends AbstractTransformer {

	@Override
	protected Object doTransform(Message<?> message) throws Exception {
		
		Object payload =  message.getPayload();

		logger.info("XML Object :: " + payload.toString());
		
		Offer offer = new Offer();

		Party party = new Party();
		party.setCustomerId("12345");
		offer.setParty(party);
		
		return offer;
	}

}
