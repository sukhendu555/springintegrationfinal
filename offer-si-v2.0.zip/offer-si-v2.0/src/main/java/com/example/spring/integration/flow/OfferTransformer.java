package com.example.spring.integration.flow;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.Transformer;

@Configuration
public class OfferTransformer {

	@Bean
	@Transformer(inputChannel = "xmlObjToJsonObjChannel", outputChannel = "xmlToJsonResponseChannel")
	public AccumulatedOutputToOfferTransformer xmlObjToJsonObjTransformer() {

		return new AccumulatedOutputToOfferTransformer();

	}

	@Bean
	@Transformer(inputChannel = "objectToXmlObjChannel", outputChannel = "objectToXmlChannel")
	public OffersToReqTransformer reqObjToXmlObjTransformer() {
		return new OffersToReqTransformer();
	}
}