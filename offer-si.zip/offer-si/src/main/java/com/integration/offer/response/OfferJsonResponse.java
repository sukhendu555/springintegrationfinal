
package com.integration.offer.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "getOfferResponse"
})
@XmlRootElement
public class OfferJsonResponse {

    @JsonProperty("getOfferResponse")
    @XmlElement
    private OfferResponse getOfferResponse;
  
    @JsonProperty("getOfferResponse")
    public OfferResponse getGetOfferResponse() {
        return getOfferResponse;
    }

    @JsonProperty("getOfferResponse")
    public void setGetOfferResponse(OfferResponse getOfferResponse) {
        this.getOfferResponse = getOfferResponse;
    }

}
