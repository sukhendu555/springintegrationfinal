package com.example.spring.integration.flow;

import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.Splitter;

import com.example.spring.integration.dto.json.request.Offers;

@MessageEndpoint
public class OfferSplitter {

	@Splitter(inputChannel = "offers", outputChannel = "offerTypeRouter")
	public Offers split(Offers offers) {
		return offers;
	}
}