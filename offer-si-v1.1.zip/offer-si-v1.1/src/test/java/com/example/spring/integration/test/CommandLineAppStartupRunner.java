package com.example.spring.integration.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;
import org.springframework.stereotype.Component;

import com.example.spring.integration.OfferApplication;
import com.example.spring.integration.controller.OfferController;
import com.example.spring.integration.dto.json.request.OfferType;
import com.example.spring.integration.dto.json.request.Offers;
import com.example.spring.integration.dto.json.request.Party;

@Component
public class CommandLineAppStartupRunner implements CommandLineRunner {
	private static final Logger LOG = LoggerFactory.getLogger(CommandLineAppStartupRunner.class);

	@Autowired
	private OfferController offerController;

	@Override
	public void run(String... args) throws Exception {
		LOG.info("Sending Offer Data to Queue");

		Offers offers = new Offers();
		offers.setType(OfferType.FVT);
		
		Party party =  new Party();
		party.setCustomerId("123456");
		party.setCardAccountNumber("897878787878");
		
		offers.setParty(party);
		
		offerController.liteOffer(new Offers());
		
	}
}