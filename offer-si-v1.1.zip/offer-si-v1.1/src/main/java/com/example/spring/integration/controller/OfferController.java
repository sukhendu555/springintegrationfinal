package com.example.spring.integration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.spring.integration.dto.json.request.Offers;
import com.example.spring.integration.dto.json.response.Offer;
import com.example.spring.integration.gateway.OfferGateway;
import com.example.spring.integration.jms.JmsMessageReceiver;

@RestController
@RequestMapping("/offer")
public class OfferController {

	@Autowired
	private OfferGateway offerGateway;

	@Autowired
	private JmsMessageReceiver jmsMessageReceiver;

	@PostMapping(path = "/liteOffer", consumes = MediaType.APPLICATION_JSON_VALUE, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<?> liteOffer(@RequestBody Offers offers) {

		System.out.println("Offers Detail: " + offers);
		try {

			offerGateway.sendOffers(offers);

			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(path = "/liteOffer", consumes = MediaType.APPLICATION_JSON_VALUE, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<?> getliteOffer() {

		try {

			Offer OfferResponse = jmsMessageReceiver.receiveMessage();

			return new ResponseEntity<>(OfferResponse, HttpStatus.OK);
		} catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}