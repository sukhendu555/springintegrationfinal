package com.example.spring.integration.flow;

import org.springframework.integration.transformer.AbstractTransformer;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.example.spring.integration.dto.json.request.Offers;
import com.example.spring.integration.dto.xml.request.Header;
import com.example.spring.integration.dto.xml.request.REQUESTS;
import com.example.spring.integration.dto.xml.request.REQUESTS.REQUEST;
import com.example.spring.integration.dto.xml.request.REQUESTS.REQUEST.HEADER;
import com.example.spring.integration.dto.xml.request.REQUESTS.REQUEST.HEADER.ACTION;
import com.example.spring.integration.dto.xml.request.REQUESTS.REQUEST.PARAMS;
import com.example.spring.integration.dto.xml.request.REQUESTS.REQUEST.PARAMS.PARAM;
import com.example.spring.integration.dto.xml.request.REQUESTS.REQUEST.PARAMS.PARAM.TABLE;
import com.example.spring.integration.dto.xml.request.REQUESTS.REQUEST.PARAMS.PARAM.TABLE.TR;
import com.example.spring.integration.dto.xml.request.Req;

@Component
public class OffersToReqTransformer extends AbstractTransformer{

	@Override
	protected Object doTransform(Message<?> message) throws Exception {

		Offers payload =  (Offers) message.getPayload(); // input

		logger.info("Offers Object :: " + payload.toString());
		logger.info("Creating Req Object");
		
		
		Req req = new Req();

		req.setHeader(new Header("LOBIndicator", "99").attribute("Channel", "AOM_CARDS_INTERNET")
				.attribute("TxnID", "191211235256007299002640-204434348").attribute("ClientIPAddress", null));

		HEADER header = new HEADER("LiteOfferandFBR", "WWWUSER", "5410654559994311", "", "Y", new ACTION("Inquire"));

		PARAMS params = new PARAMS(
				new PARAM(new TABLE("LiteOfferInquiry").tr(new TR().td("AccountNumber", "5410654559994311")
						.td("AccountNumber", "5410654559994311")
						.td("Feedback", "Y")
						.td("SOC", "Y")
						.td("Balcon", "L")
						.td("DOE", "Y")
						.td("MaxFeedBack", "0200")
						.td("MaxSOC", "00020")
						.td("MaxDOE", "00020")
						.td("MaxBalcon", "00005")
						.td("MaxFeedBackDays", "30")
						.td("ChannelInd", "03")
						.td("RateSaleIndicator", "Y")
						
						)));

		 REQUEST request = new REQUEST("TestReqyest", header , params);

		 req.setREQUESTS(new REQUESTS(request));
		 
		
		return req;
	}

}
