
package com.example.spring.integration.dto.json.response;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "offer"
})
@XmlRootElement
public class OfferResponse {

    @JsonProperty("offer")
    @XmlElement
    private List<Offer> offer = new ArrayList<Offer>();
  
    @JsonProperty("offer")
    public List<Offer> getOffer() {
        return offer;
    }

    @JsonProperty("offer")
    public void setOffer(List<Offer> offer) {
        this.offer = offer;
    }

}
