package com.example.spring.integration.test;

public class RequestTest {

}
