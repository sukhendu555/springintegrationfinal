package org.integration.offer.annotation;

import java.util.List;

import org.integration.offer.Delivery;
import org.integration.offer.Offers;
import org.springframework.integration.annotation.Aggregator;
import org.springframework.integration.annotation.CorrelationStrategy;
import org.springframework.integration.annotation.MessageEndpoint;

/**
 * @author Marius Bogoevici
 */
@MessageEndpoint
public class OfferAggregator {

	@Aggregator(inputChannel = "preparedOffer", outputChannel = "deliveries")
	public Delivery prepareDelivery(List<Offers> drinks) {
		return new Delivery(drinks);
	}

//	@CorrelationStrategy
//	public int correlateByOrderNumber(Offers drink) {
//		return drink.getOrderNumber();
//	}

}
