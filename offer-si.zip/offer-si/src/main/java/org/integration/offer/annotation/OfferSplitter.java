

package org.integration.offer.annotation;

import org.integration.offer.Offers;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.Splitter;

/**
 * @author Mark Fisher
 */
@MessageEndpoint
public class OfferSplitter {

	@Splitter(inputChannel="orders", outputChannel="drinks")
	public Offers split(Offers offers) {
		return offers;
	}

}
