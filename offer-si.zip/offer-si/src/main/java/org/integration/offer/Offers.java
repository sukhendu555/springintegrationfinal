
package org.integration.offer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.integration.offer.request.CopsGetPartyOfferListRequest;
import com.integration.offer.request.CorOfferExtention;
import com.integration.offer.request.Party;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "party",
    "copsGetPartyOfferListRequest",
    "corOfferExtention"
})
@XmlRootElement
public class Offers {

    @JsonProperty("party")
    @XmlElement
    private Party party;
    @JsonProperty("copsGetPartyOfferListRequest")
    @XmlElement
    private CopsGetPartyOfferListRequest copsGetPartyOfferListRequest;
    @JsonProperty("corOfferExtention")
    @XmlElement
    private CorOfferExtention corOfferExtention;
    
    @JsonIgnore
    private OfferType type;
   
    @JsonProperty("party")
    public Party getParty() {
        return party;
    }

    @JsonProperty("party")
    public void setParty(Party party) {
        this.party = party;
    }

    @JsonProperty("copsGetPartyOfferListRequest")
    public CopsGetPartyOfferListRequest getCopsGetPartyOfferListRequest() {
        return copsGetPartyOfferListRequest;
    }

    @JsonProperty("copsGetPartyOfferListRequest")
    public void setCopsGetPartyOfferListRequest(CopsGetPartyOfferListRequest copsGetPartyOfferListRequest) {
        this.copsGetPartyOfferListRequest = copsGetPartyOfferListRequest;
    }

    @JsonProperty("corOfferExtention")
    public CorOfferExtention getCorOfferExtention() {
        return corOfferExtention;
    }

    @JsonProperty("corOfferExtention")
    public void setCorOfferExtention(CorOfferExtention corOfferExtention) {
        this.corOfferExtention = corOfferExtention;
    }

    public OfferType getType() {
        return type;
    }

    public void setType(OfferType type) {
        this.type = type;
    }
    
    
}
